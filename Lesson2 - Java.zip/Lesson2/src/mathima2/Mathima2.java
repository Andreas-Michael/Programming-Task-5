/*
2η for

Να κατασκευαστεί υπερκλάση Song που περιέχει τα πεδία title και duration (διάρκεια).
Να γράψετε constructor, get, 1 set, toString.

Να κατασκευαστεί υποκλάση RockSong  που περιέχει το πεδίο bandName.
Να γράψετε constructor, get, 1 set, toString.

Να κατασκευαστεί υποκλάση PopSong  που περιέχει το πεδίο release_year.
Να γράψετε constructor, get, 1 set, toString.

Να κάνετε 1 πίνακα με 3 τραγούδια (1 τραγούδι από κάθε κλαση) και να εμφανίσετε τα στοιχεία του.
 */
package mathima2;

import java.util.Scanner;

/**
 *
 * @author theo
 */
public class Mathima2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* είσοδος απο πληλτρολόγιο */
        /*
        // Για είσοδο από πληκτρολόγιο χρησιμοοπιύμε την κλάση Scanner και 
        // πρέπει να κατασκευάσουμε ένα αντικείμενο της κλάσης δίνοντας ως όρισμα
        // στον constructor το System.in ώστε η ανάγνωση να γίνεται από το 
        // πληκτρολόγιο
        Scanner input = new Scanner(System.in);
        
        System.out.println("Δώσε το όνομά σου:");
        String name = input.next(); // διαβάζει μεχρι το πρώτο κενό, [tab] ή την αλλαγή γραμμής
                                    // αν μετά το κενό η το [tab] ακολουθούν και άλλοι 
                                    // χαρακτήρες, αυτοί δεν χάνονται, αλλα παραμένουν στην
                                    // μνήμη και μπορώ να τους τραβήξω με μια επόμενη εντολή
                                    // .next()
        System.out.println("Γειά σου " + name);

        System.out.println("Δώσε το επίθετό σου:");
        String surname = input.next();
        System.out.println("Γεια σου " + name + " " + surname);
        
        input.nextLine(); // ξεφορτωνομαι την αλλαγή γραμμής που έχει μέίνει από το
                           // προηγούμενο .next()
        
        System.out.println("Δώσε όνομα και επίθετο:");
        String full_name = input.nextLine();  // διαβάζει μέχρι την αλλαγή γραμμής
        System.out.println("Γειά σου " + full_name);
        
        System.out.println("Δώσε έτος γέννησης:");
        int year = input.nextInt();
        
        System.out.println("Είσαι ετών " + (2017-year));
        */
        
        /*
        Όταν σε μια κλάση δεν έχω κανέναν constructor η JAVA κατασκευαζει αυτόματα
        από μόνη της έναν κενό constructor, ο οποίος δηλαδή δεν δέχεται ορίσματα και
        που αρχικοποιεί όλα τα πεδία σε εξορισμού τιμές, δηλαδή τα αντικείμενα σε 
        null και τα αριθμητικά πεδία σε 0.
        
        Αν μια κλάση περιέχει constructor τότε η JAVA δεν κατασκευάζει κανέναν
        constructor αυτόματα.
        */
        //Book b1 = new Book();
        //b1.pages = 120;
        //b1.print_info();
        
        Book b1 = new Book("Learn JAVA", 1200);
        b1.print_info();
        
        ComicBook comicBook1 = new ComicBook("Superman is back", 56, "Superman");
        comicBook1.print_info();
        
        System.out.println(comicBook1);
        
        /* Πίνακες */
        System.out.println(" ** Πίνακες ** ");
        Book array[];
        array = new Book[3]; // δηλώνω οτι ο πίνακας θα αποτελείται από 3 στοιχεία
                            // οπότε η JAVA μου κρατάει την απαραίτητη μνήμη, αλλά
                            // οι θέσεις είναι κενές, επειδή δεν έχω καταχωρήσει 
                            // κανένα αντικείμενο!
                            
        System.out.println(array[0]); // είναι null γιατί η θέση είναι κενή
        
        array[0] = comicBook1;
        array[1] = new ComputerBook("Learn PHP", 200, "PHP"); // ανώνυμο αντικείμενο
        array[2] = b1;
        
        /*
        Μπορώ να δηλώσω μια μεταβλητή επανάληψης μέσα στην for, αλλά η μεταβλητή 
        αυτή θα υπάρχει μόνο για όσο εκτελείται η επανάληψη. Μετα η μεταβλητή χάνεται!
        
        Στην JAVA κάθε πίνακας γνωρίζει το μέγεθός του με το .length
        */
        for (int i = 0 ;i < array.length ; i++)
            System.out.println(array[i]);
        
        // System.out.println(array[i - 1]); Λάθος, γιαταί δεν υπάρχει η εταβλητή i
    }
    
}
