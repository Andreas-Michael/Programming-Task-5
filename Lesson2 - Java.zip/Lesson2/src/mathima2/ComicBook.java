/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima2;

/*
Όταν θέλω να κρατήσω τα χαρακτηριστικά μιας κλάσης (υπερκλάση) και να προσθέσω
περισσότερα στοιχεία κατασκευάζω μια νέα κλάση (υποκλάση) η οποία κληρονομεί όλα
τα στοιχεία της υπερκλάσης (έτοιμος κώδικας, πεδία, μέθοδοι κτλ).

Για να γίνει αυτό πρέπει στη δήλωση της υποκλασης να προσθέσω την εντολή 
extends [όνομα_υπερκλάσης]
 */
public class ComicBook extends Book{
    private String hero;
    
    public ComicBook(String title, int pages, String hero){
        /*
        Εφόσον η υποκλάση κληρονομεί από την υπερκλάση θα πρέπει οπωσδήποτε το 
        πρώτο πράγμα που γράφω στον constructor να είναι η κλήση super, δηλαδή
        μια κλήση σε κάποιον constructor της υπερκλάσης. Εδώ προφανώς καλούμε τον
        constructor Book(String title, int pages) της Book
        */
        super(title, pages); // Book(String title, int pages)
        this.hero = hero;
        //this.pages = 120;
    }
    
    /*
    Override (υπέρβαση): όταν μια μέθοδος της υπερκλάσης υπάρχει ακριβώς η ίδια
            σε κάποια υποκλάση της.
    */
    @Override
    public void print_info(){
        System.out.print("Comic ");
        /*
        Αν θέλω να καλέσω κάποια μέθοδο της υπερκλάσης που έχουμε κάνει Override, 
        πρέπει να βάλω πριν το όνομα της μεθόδου το προσδιοριστικό super.
        */
        super.print_info();
    }
    
    /*
    Η πρώτη κλάση στην JAVA είναι η κλάση Object. Η κλάση αυτή είναι η υπερκλάση 
    όλων των κλάσεων της JAVA (άμεσα ή έμμεσα). Όλες οι κλάσεις στην JAVA είναι 
    υποκλάσεις της Object. Μια από τις μεθόδους που κληροδοτεί η Object στις 
    υποκλάσεις της είναι και μέθοδος toString() η οποία καλείτα αυτόματα όταν 
    ζηταμε να τυπώσουμε ένα αντικείμενο. 
    
    Βέβαια θα μπορούσαμε να κάνουμε Override στην toString() σε οποιαδήποτε 
    υποκλάση και να αλλάξουμε το μήνυμα που εμφανίζεται οταν ζητάμε να τυπώσουμε
    ενα αντικείμενο.
    */
    public String toString(){
        return "Comic book title is " + get_title();
    }
}
