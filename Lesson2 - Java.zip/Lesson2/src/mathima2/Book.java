/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima2;

/*
Επίπεδα πρόσβασης μελών της κλάσης:

private: κανείς εκτός της κλάσης δεν έχει πρόσβαση στο μελη της κλάσης

(πρόσβαση σε επίπεδο πακέτου): πρόσβαση σε αυτά τα μέλη έχουν οι κλασεις που
        ανήκουν στο ίδιο πακέτο (πχ package mathima2). Για να δηλώσω ένα μέλος
        με αυτόν τον τρόπο δεν γράφω κανένα αναγνωριστικό πχ
                int x;
                void f(){ ... }

protected: τα προστευτόμενα μέλη μιας κλάσης είναι ορατά από τις υποκλάσης της 
        και από τις κλάσεις του ίδιου πακέτου, πχ (package  mathima2)

public: η πρόσβαση στα μέλη που είναι δημόσια επιτρέπεται από οποιοδήποτε σημείο
 */
public class Book {
    private String title;
    protected int pages;
    
    public Book(String title, int pages){
        this.title = title;
        this.pages = pages;
    }
    
    public void print_info(){
        System.out.println("* Book title: " + title + ", pages: " + pages + "*");
    }
    
    public String get_title(){
        return title;
    }
}
