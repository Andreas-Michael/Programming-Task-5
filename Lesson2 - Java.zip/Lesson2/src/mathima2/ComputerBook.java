/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima2;

/**
 *
 * @author theo
 */
public class ComputerBook extends Book{
    private String field;
    
    public ComputerBook(String title, int pages, String field){
        super(title, pages);
        this.field = field;
    }
    
    public String toString(){
        return "Computer book title " + get_title();
    }
}
