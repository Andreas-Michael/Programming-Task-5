/*
Να κατασκευαστεί μια κλάση Boat η οποία θα περιέχει τα πεδία name, shipYear και 
carriage. Να κατασκευαστούν 2 constructors και μέθοδοι get και 1 set (αλλάζει το 
carriage).

Na κατασκευάσετε 2 αντικείμενα της κλάσης και να εμφανίσετε τα πεδία τους.
 */
package mathima1;

/**
 *
 * @author theo
 */
public class Mathima1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Μπορώ να χρησιμοποιήσω ένα στατικό πεδίο χωρίς να υπάρχει 
        // κάποιο αντικείμενο
        System.out.println("MIN_PAGES: " + Book.MIN_PAGES);
        // Book.print_info(); δεν γίνεται να καλέσω την μέθοδο αυτή
                             // γιατί δεν είναι στατική και θα πρέπει
                             // να υπάρχει αντικείμενο της κλάσης για να 
                             // την καλέσω
        // μπορώ να καλέσω μια στατική μέθοδο χωρίς να υπάρχει κάποιο 
        // αντικείμενο της κλάσης
        Book.static_method();
        System.out.println("π = " + Math.PI);
        double max = Math.max(12.23, 123.1230);
        System.out.println("max=" + max);
        /*
        Θέλω να κατασκευασω ένα αντικείμενο της κλασης Book. Χρησιμοποιώ
        την εντολή new και τον constructor της κλάσης: 
            public Book(String title, int pages, double price)
        
        Το νέο αντικείμενο που δημιουργήθηκε έχει αποθηκευτεί στην μεταβλητή
        (δείκτης) b1 που έχει τύπο Book.
        */
        Book b1 = new Book("Absolute JAVA", 1200, 100.95);
        // b1.pages++; δεν μπορώ να έχω πρόσβαση σε ένα ιδιωτικό πεδίο της κλάσης
        b1.MIN_PAGES = 100;
        b1.print_info();
        
        
        Book b2 = new Book("Absolute C", 550, 45.85);
        b2.print_info();
        
        Book b3 = new Book("Absolute PHP", 35);
        b3.print_info(false);
        System.out.println("images: " + b3.IMAGES);
        //b3.IMAGES++;
        System.out.println("MIN_PAGES: " + b3.MIN_PAGES);
    }
    
}
