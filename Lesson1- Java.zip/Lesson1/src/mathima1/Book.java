/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima1;

/*
Συνηθίζεται να γράφουμε στο όνομα της κλάσης το πρώτο γράμμα κεφαλαίο, πχ Book.
Επομένως και ο τύπος String είναι στην πραγματικότητα μια κλάση και όχι βασικός
τύπος όπως είναι το int, float, double.

Κάθε κλάση γράφεται σε ένα δικό τς αρχείο που θα πρέπει να έχει ακριβώς το ίδιο
όνομα με το όνομα της κλάσης (Book.java)
 */
public class Book {
    // πεδία της κλάσης (μεταβλητές της κλάσης)
    // τα πεδία πρέπει να είναι ιδιωτικά (private) έτσι ώστε να μην υπάρχει
    // πρόσβαση σε αυτή για ανάγνωση ή εγγραφή εκτός της κλασης.
    private String title;
    private int pages;
    private double price;
    
    /*
    Όταν ένα πεδίο είναι στατικό (static) δεν είναι δυναμικό, επομένως δεν 
    σχηματίζει αντίγραφα σε κάθε νέο αντικείμενο που δημιουργείται. Δηλαδή 
    υπάρχει σε ένα μοναδικό σημείο στην μνήμη μέσα στον ορισμό της κλάσης
    και είναι κοινόχρηστο. Δηλαδή όλα τα αντικείμενα μοιράζονται το ίδιο 
    πεδίο.
    */
    public static int MIN_PAGES = 3;
    
    
    public final static int MAX_PAGES = 1000;
    
    /*
    Τα final πεδία πρέπει οπωσδήποτε να αρχικοποιηθούν σε ό λους τους constructor
    της κλάσης και από την στιγμή που θαλάβουν κάποια τιμή δεν μπορεί να αλλάξει
    η τιμή τους.
    */
    public final int IMAGES;
    
    // μέθοδοι της κλάσης (συναρτήσεις)
    /*
    constructor (μέθοδος δημιουργίας): εκχωρεί νέα μνήμη για την κατασκευή ενός
            νέου αντικειμένου της κλάσης και επισης αρχικοποιεί όλα τα πεδία της
            κλάσης. Οι constructors διαφερουν από τις υπόλοιπες μεθόδους σε 2 
            σημεία:
                1) έχουν ακριβώς το ίδιο όνομα με το όνομα της κλάσης (Book)
                2) δεν έχουν τύπο επιστροφής πχ public VOID f(){ ... }    
    */
    public Book(String title, int pages, double price){
        /*
        Αρχικοποίηση των πεδίων της κλάσης με τις τιμές των ορισμάτων που δέχετε
        η μέθοδος. Για να μπορέσει η JAVA να ξεχωρίσει ποιο title είναι πεδίο 
        και πιο είναι όρισμα της μεθόδου, πρέπει μπροστά από το πεδίο τηςκλάσης 
        να προσθέσω και το προσδιοριστικό this.
        */
        this.title = title;
        this.price = price;
        this.pages = pages;
        
        IMAGES = 10;
    }
    
    /*
    overloading (υπερφόρτωση): όταν υπάρχουν 2 ή περισσότερες μέθοδοι μέσα στην 
            ίδια κλάση που διαφερουν μόνο στα ορίσματα που δέχονται.
    */
    public Book(String title, int images){
        this.title = title;
        
        /*
        Επειδή δεν έχω αρχικοποιήσει τα υόλοιπα πεδία της κλάσης η JAVA τα
        αρχικοποιεί σε μια εξορισμού τιμή, (για τους βασικους τύπους είναι 
        το 0 και για τα ααντικείμενα είναι το null). Εξαίρεση αποτεούν τα
        final πεδία που θα πρεπει ρητά να αρχικοποιηθούν σε κάποια τιμή.
        */
        
        IMAGES = images;
    }
    
    // άλλες μέθοδοι της κλάσης
    public void print_info(){
        // sout + [tab]
        System.out.println("Τίτλος: " + title + ", σελίδες: " + pages +
                    ", τιμή: " + price);
    }
    // overloading
    public void print_info(boolean inGreek){
        if (inGreek == true){
            System.out.println("Τίτλος: " + title + ", σελίδες: " + pages +
                    ", τιμή: " + price);
        }
        else {
            System.out.println("title: " + title + ", pages: " + pages +
                    ", price: " + price);
        }
    }
    
    // μέθοδοι get
    public String get_title(){
        return title;
    }
    
    public int get_pages(){
        return pages;
    }
    
    public double get_price(){
        return price;
    }
    
    // μέθοδοι set
    public void set_price(double new_price){
        if (new_price > 0) price = new_price;
        else System.out.println("Δεν μπορεί να έχει αρνητική τιμή ένα βιβλίο!");
    }
    /*
    Οι στατικές μέθοδοι μπορούν να κληθούν χωρις να υπάρχει κάποιο αντικείμενο.
    Αυτο είναι χρησιμό σε κάποιες κλάσεις που παρέχουν κάποιες σύντομες μεθόδους,
    όπως πχ η Math με την Math.max()
    */
    public static void static_method(){
        System.out.println("Hello from a static method");
    }
}
