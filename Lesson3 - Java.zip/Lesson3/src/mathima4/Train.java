/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima4;

import java.util.LinkedList;

/**
 *
 * @author theo
 */
public class Train {
    private LinkedList<Carriage> list;
    
    public Train(){
        list = new LinkedList();
    }
    
    public String toString(){
        if (list.isEmpty() == false){
            String r = "";
            
            for (Carriage carriage: list){
                r += carriage;
            }
            return r;
        }
        else return "";
    }
    
    public void addLocomotive(Locomotive loc) throws TrainException{
        // object instanceof class: επιστρεφει true αν το αντικείμενο
        //          object ανηκει στην κλάση class
        if (list.isEmpty() == false && list.getFirst() instanceof Locomotive)
            throw new TrainException("Υπάρχει ήδη μηχανή, δεν μπορεί να αλλάξει");
        
        list.addFirst(loc);
    }
    
    public void addCarFront(Carriage car)throws TrainException{
        // object instanceof class: επιστρεφει true αν το αντικείμενο
        //          object ανηκει στην κλάση class
        if (list.isEmpty() == false && list.getFirst() instanceof Locomotive)
            throw new TrainException("Δεν μπορεί να προστεθεί βαγόνι μπροστά από "
                    + "τη μηχανή");
        
        list.addFirst(car);
    }
    
    public void addCarBack(Carriage car){        
        list.addLast(car);
    }
}
