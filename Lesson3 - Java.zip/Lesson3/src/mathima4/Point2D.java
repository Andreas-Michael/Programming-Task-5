/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima4;

/**
 *
 * @author theo
 */
public class Point2D {
    double x, y;
    
    public Point2D(double x, double y){
        this.x = x; 
        this.y = y;
    }
    
    public double dist(){
        return Math.sqrt(Math.pow(x, 2) + y*y);
    }
    
    public static double dist(Point2D p){
        return Math.sqrt(Math.pow(p.x, 2) + p.y * p.y);
    }
}
