/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima4;

/**
 *
 * @author theo
 */
public class TrainException extends Exception {

    /**
     * Creates a new instance of <code>TrainException</code> without detail
     * message.
     */
    public TrainException() {
    }

    /**
     * Constructs an instance of <code>TrainException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public TrainException(String msg) {
        super(msg);
    }
}
