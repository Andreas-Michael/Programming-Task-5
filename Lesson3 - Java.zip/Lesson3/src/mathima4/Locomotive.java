/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima4;

/**
 *
 * @author theo
 */
public class Locomotive extends Carriage{
    
    public Locomotive(String id){
        super(id);
    }
    
     public String toString(){
        return get_id() + "--";
    }
}
