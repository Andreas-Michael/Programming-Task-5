/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathima4;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author theo
 */
public class Mathima4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Δημιουργία αρχείου κειμένου
        /*
        try{
            PrintWriter pw = new PrintWriter(new File("text.txt"));
            
            pw.println("Hello, this is my 1 st");
            pw.println("JAVA text file!");
            
            pw.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }
        */
        
        // Ανάγνωση από αρχείο κειμένου
        /*
        try{
            Scanner input = new Scanner(new File("text.txt"));
            
            //String line = input.nextLine();
            //System.out.println(line);
            String word;
            int i;
            
            while (input.hasNext()){
                if (input.hasNextInt()){
                    i = input.nextInt();
                    System.out.println("---> " + i);
                }
                else {
                    word = input.next();
                    System.out.println(word);
                }
            }
            
            input.close();
        }
        catch (IOException e){
            System.out.println(e);
        }
*/
        /*
        try{
            Train train = new Train();
            
            train.addCarFront(new Carriage("LX123"));
            train.addLocomotive(new Locomotive("LOC123"));
            train.addCarBack(new Carriage("ASX123"));
            
            System.out.println(train);
            
            train.addCarFront(new Carriage("QWE123"));
        }
        catch (TrainException e){
            System.out.println(e);
        }
*/
        Scanner input = new Scanner(System.in);
        System.out.print("Πόσα σημεία θα έχει το πολύγωνο: ");
        int plithos = input.nextInt();
        double x, y;
        Point2D array[] = new Point2D[plithos];
        
        for (int i = 0 ; i < plithos ; i++){
            System.out.print("Δώστε τις συντεταγμένες του " + (i+1) +
                    "ου σημείου");
            x = input.nextDouble();
            y = input.nextDouble();
            array[i] = new Point2D(x, y);
        }
    }
    
}
